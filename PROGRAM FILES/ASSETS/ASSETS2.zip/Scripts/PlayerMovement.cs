using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float turnSpeed = 20f;
    public GameObject firstPersonCamera;
    public GameObject thirdPersonCamera;
    Animator m_Animator;
    Vector3 m_Movement; //'m' for member variable, non-public variable    
    Quaternion m_Rotation = Quaternion.identity;
    Rigidbody m_RigidBody;
    AudioSource m_AudioSource;
    bool m_IsInFirstPerson;

    void Start()
    {
        m_Animator = GetComponent<Animator>(); //gets GameObject's Animator component (an instance)
        m_RigidBody = GetComponent<Rigidbody>();
        m_AudioSource = GetComponent<AudioSource>();
    }

void FixedUpdate()
{
    float horizontal = -Input.GetAxis("Horizontal"); // Inversăm semnul pentru a schimba direcția orizontală
    float vertical = -Input.GetAxis("Vertical"); // Inversăm semnul pentru a schimba direcția verticală

    if (Input.GetKeyDown(KeyCode.C))
    {            
        firstPersonCamera.SetActive(!firstPersonCamera.activeInHierarchy);
        thirdPersonCamera.SetActive(!thirdPersonCamera.activeInHierarchy);
        m_IsInFirstPerson = firstPersonCamera.activeInHierarchy;
    }

    if (m_IsInFirstPerson)
    {
        // Obținem direcția camerei pe axele X și Z
        Vector3 cameraForward = firstPersonCamera.transform.forward;
        cameraForward.y = 0f;  // Ne asigurăm că mișcarea nu are componentă pe axa Y
        cameraForward.Normalize();

        Vector3 cameraRight = firstPersonCamera.transform.right;
        cameraRight.y = 0f; // La fel, eliminăm componenta pe Y
        cameraRight.Normalize();

        // Inversăm mișcarea pe axele X și Z
        m_Movement = -cameraForward * vertical + -cameraRight * horizontal; // Semne inversate
    }
    else
    {
        // Dacă suntem în mod third-person, mișcarea rămâne aceeași
        m_Movement.Set(horizontal, 0f, vertical);
    }

    m_Movement.Normalize();

    bool hasHorizontalInput = !Mathf.Approximately(horizontal, 0f);
    bool hasVerticalInput = !Mathf.Approximately(vertical, 0f);

    bool isWalking = hasHorizontalInput || hasVerticalInput;
    m_Animator.SetBool("IsWalking", isWalking);

    if(isWalking)
    {
        if (!m_AudioSource.isPlaying)
        {
            m_AudioSource.Play();
        }            
    }
    else
    {
        m_AudioSource.Stop();
    }

    Vector3 desiredForward = Vector3.RotateTowards(transform.forward, m_Movement, turnSpeed * Time.deltaTime, 0f);
    m_Rotation = Quaternion.LookRotation(desiredForward);
}



    void OnAnimatorMove()
    { 
        m_RigidBody.MovePosition(m_RigidBody.position + m_Movement * m_Animator.deltaPosition.magnitude);
        m_RigidBody.MoveRotation(m_Rotation);
    }
}
